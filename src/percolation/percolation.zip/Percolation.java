import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private boolean[][] grid;
    private WeightedQuickUnionUF fullUF, auxUF;
    private int size, above, below, openSites;

    public Percolation(int n) {
        // create n-by-n grid, with all sites blocked
        if (n <= 0)
            throw new IllegalArgumentException("n needs to be > 0");

        this.size = n;
        this.grid = new boolean[n][n];
        this.fullUF = new WeightedQuickUnionUF(n * n + 2);
        this.auxUF = new WeightedQuickUnionUF(n * n + 1);
        this.above = n * n;
        this.below = n * n + 1;
        this.openSites = 0;
    }

    private void connectToVirtualEdges(int point) {
        if (point >= 0 && point < this.size) {
            // Connect virtual top to first row
            this.fullUF.union(this.above, point);
            this.auxUF.union(this.above, point);
        }

        if (point >= this.size * this.size - this.size && point < this.size * this.size) {
            // Connect virtual bottom to last row
            this.fullUF.union(this.below, point);
        }
    }

    private boolean areIndexesInRange(int row, int col) {
        return row > 0 && row <= this.size && col > 0 && col <= this.size;
    }

    private int xyTo1D(int row, int col) {
        return (this.size * (row - 1) + col - 1);
    }

    private void connectCells(int r1, int c1, int r2, int c2) {
        int p1 = this.xyTo1D(r1, c1);
        int p2 = this.xyTo1D(r2, c2);
        this.fullUF.union(p1, p2);
        this.auxUF.union(p1, p2);
    }

    public void open(int row, int col) {
        if (!this.areIndexesInRange(row, col))
            throw new java.lang.IndexOutOfBoundsException();
        if (this.isOpen(row, col))
            return;

        int pointToBeOpened = this.xyTo1D(row, col);

        this.grid[row - 1][col - 1] = true;
        this.openSites++;

        // Connect it to all open adjacent sites:
        if (row > 1) {
            if (this.isOpen(row - 1, col)) {
                connectCells(row, col, row - 1, col);
            }
        }
        if (row < this.size) {
            if (this.isOpen(row + 1, col)) {
                connectCells(row, col, row + 1, col);
            }
        }
        if (col > 1) {
            if (this.isOpen(row, col - 1)) {
                connectCells(row, col, row, col - 1);
            }
        }
        if (col < this.size) {
            if (this.isOpen(row, col + 1)) {
                connectCells(row, col, row, col + 1);
            }
        }

        /*
         * int[][] adjacents = this.getAdjacentSites(row, col);
         * 
         * for (int[] adjacent : adjacents) { if (this.areIndexesInRange(adjacent[0],
         * adjacent[1]) && this.isOpen(adjacent[0], adjacent[1])) { int adjacentOpenSite
         * = this.xyTo1D(adjacent[0], adjacent[1]);
         * 
         * this.fullUF.union(pointToBeOpened, adjacentOpenSite);
         * this.auxUF.union(pointToBeOpened, adjacentOpenSite); } }
         */

        this.connectToVirtualEdges(pointToBeOpened);
    }

    public boolean isOpen(int row, int col) {
        if (!this.areIndexesInRange(row, col))
            throw new java.lang.IndexOutOfBoundsException();

        return this.grid[row - 1][col - 1];
    }

    public boolean isFull(int row, int col) {
        if (!this.areIndexesInRange(row, col))
            throw new java.lang.IndexOutOfBoundsException();

        return this.isOpen(row, col) && this.auxUF.connected(this.xyTo1D(row, col), this.above);
    }

    public int numberOfOpenSites() {
        return this.openSites;
    }

    public boolean percolates() {
        return this.fullUF.connected(this.above, this.below);
    }

    public static void main(String[] args) {
        System.out.println("Percolation");
    }
}